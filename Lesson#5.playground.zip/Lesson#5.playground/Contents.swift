import Foundation
import Darwin

//1. Создать протокол «Car» и описать свойства, общие для автомобилей, а также метод действия.
//2. Создать расширения для протокола «Car» и реализовать в них методы конкретных действий с автомобилем: открыть/закрыть окно, запустить/заглушить двигатель и т.д. (по одному методу на действие, реализовывать следует только те действия, реализация которых общая для всех автомобилей).
//3. Создать два класса, имплементирующих протокол «Car» - trunkCar и sportСar. Описать в них свойства, отличающиеся для спортивного автомобиля и цистерны.
//4. Для каждого класса написать расширение, имплементирующее протокол CustomStringConvertible.
//5. Создать несколько объектов каждого класса. Применить к ним различные действия.
//6. Вывести сами объекты в консоль.

enum Action {
    case engineTurnOn, engineTurnOff
    case nitroOn, nitroOff
    case setCarge, resetCarge
}

protocol Car: AnyObject {
    var model: String {get set}
    var horsePower: Int {get set}
    var isEngineOn: Bool {get set}
    
    func perform(action: Action)
}
 
extension Car {
   
}

func performEngineAction(action: Action){
switch action {
case .engineTurnOff:
    isEngineOn = false
case .engineTurnOn:
    isEngineOn = true
default:
    break
}
}


class SportCar: Car {
    var model: String = ""
    var horsePower: Int = 0
    var isEngineOn: Bool = true
    
    var isNitroOn: Bool = false {
        didSet {
            print ("Свойство isNitroOn изменено на \(isNitroOn)")
    }
}

    func perform(action: Action) {
switch action {
case .engineTurnOff:
    isEngineOn = false
case .engineTurnOn:
    isEngineOn = true
default:
    break
}

        func performEngineAction(action: Action){
  }
}
extension SportCar: CustomStringConvertible {
    
    var description: String {
        return "This sportCar with hoursePower \(horsePower)"
    }
}

    class TrunkCar: Car {
        var model: String = ""
        var horsePower: Int = 0
        var isEngineOn: Bool = false
        
        var hasCargo: Bool = false {
            didSet {
                print ("Свойство hasCargo изменено на \(hasCargo)")
        }
    }
        func perform(action: Action){
        switch action {
        case .setCarge:
            hasCargo = true
        case .resetCarge:
            hasCargo = false
        default:
            break
        }
       
            func performEngineAction(action: Action) {
        
    }
}

let sportCar = SportCar()
let trunkCar = TrunkCar()

sportCar.perform(action: .nitroOn)
sportCar.perform(action: .setCarge)

trunkCar.perform(action: .setCarge)
trunkCar.perform(action: .nitroiOn)

