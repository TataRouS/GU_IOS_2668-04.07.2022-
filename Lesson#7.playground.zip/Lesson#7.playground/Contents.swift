import Foundation

//1. Придумать класс, методы которого могут завершаться неудачей и возвращать либо значение, либо ошибку Error?. Реализовать их вызов и обработать результат метода при помощи конструкции if let, или guard let.
//2. Придумать класс, методы которого могут выбрасывать ошибки. Реализуйте несколько throws-функций. Вызовите их и обработайте результат вызова при помощи конструкции try/catch.

enum UserAnswerInputError: Error {
    case wrongInput
    case useranswerEmpty
}

    class userAnswer {
               func userAnswerInput() -> String? {
                   guard let userAnswer = readLine() else {
            return nil
        }
       
                   guard !userAnswer.isEmpty else {
            return nil
    }
                   return userAnswer
}

    if let userAnswer = userAnswerInput() {
        print ("Ответ пользователя: \(userAnswer)")
    } else {
        print("Error!")
    }


     class userAnswer {
                func userAnswerInput() -> String {
                    guard let userAnswer = readLine() else {
                        throw UserAnswerInputError.wrongInput
                    }
                   
                guard !userAnswer.isEmpty else {
                    throw UserAnswerInputError.useranswerEmpty
                }
              return userAnswer
            }
         
         func userAnswer() {
             
             do {
                 print ("Введите ответ")
                 let userAnswer = try userAnswerInput()
                 print ("Ответ пользователя: \(userAnswer)")
             } catch {
                 if let userAnswerInputError = Error as? UserAnswerInputError {
                     switch usernameInputError {
                     case .wrongInput:
                         print("Ошибка ввода")
                     case .useranswerEmpty:
                         print("Пустая строка")
                     }
                 }
             }
         }
         
userAnswer()
