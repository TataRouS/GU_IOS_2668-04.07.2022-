import Foundation

//1. Реализовать свой тип коллекции «очередь» (queue) c использованием дженериков.
//2. Добавить ему несколько методов высшего порядка, полезных для этой коллекции (пример: filter для массивов)
//3. * Добавить свой subscript, который будет возвращать nil в случае обращения к несуществующему индексу.

struct Queue<Element> {
    var elements: [Element] = []
    
    var peek: Element? {
        return elements.first
        
    }
    
    mutating func enqueue (_ element: Element) {
        elements.append(element)
    }
    
    mutating func dequeue() -> Element? {
        return elements.isEmpty ? nil : elements.removeFirst()
    }
    
    func map (_ transform: (Element) -> Element) -> [Element] {
        var transformedArry: [Element] = []
        for element in elements {
            let transformedElement = transform(element)
            transformedArry.append(transformedElement)
        }
    return transformedArry
    }
    
}

var queue = Queue<Int>()

queue.enqueue(1)
queue.enqueue(2)
queue.enqueue(3)

let newArray = queue.map {$0 * 3}
newArray

queue.peek
queue.dequeue()

queue.dequeue()
queue.peek

queue.dequeue()
queue.dequeue()


