import Foundation

//1. Описать класс Car c общими свойствами автомобилей и пустым методом действия по аналогии с прошлым заданием.
//2. Описать пару его наследников trunkCar и sportСar. Подумать, какими отличительными свойствами обладают эти автомобили. Описать в каждом наследнике специфичные для него свойства.
//3. Взять из прошлого урока enum с действиями над автомобилем. Подумать, какие особенные действия имеет trunkCar, а какие – sportCar. Добавить эти действия в перечисление.
//4. В каждом подклассе переопределить метод действия с автомобилем в соответствии с его классом.
//5. Создать несколько объектов каждого класса. Применить к ним различные действия.
//6. Вывести значения свойств экземпляров в консоль.
enum Action {
    case engineTurnOn, engineTurnOff
    case nitroOn, nitroOff //SportCar
    case setCargo, resetCargo //TrunkCar
}


class Car {
    let model: String
    let hoursePower: Int
    var isEngineOn: Bool = false
    
    init (model: String, hoursePower: Int) {
        self.model = model
        self.hoursePower = hoursePower
    }
    func perform (action: Action) {
        switch action {
        case .engineTurnOff:
            isEngineOn = false
        case .engineTurnOn:
            isEngineOn = true
        default:
            break
        }
    }
}

class SportCar: Car {
    var isNitroOn: Bool = false {
        didSet {
            print("Свойство  isNitroOn изменено на \(isEngineOn)")
        }
    }
    
    override func perform(action: Action) {
        super.perform(action: action)
        
        switch action {
        case .nitroOff:
            isNitroOn = false
        case .nitroOn:
            isNitroOn = true
        default:
            break
            }
    }
    
}

class TrunkCar: Car {
    var hasCargo: Bool = false
    {
        didSet {
            print("Свойство hasCargo  изменено на \(hasCargo)")
        }
    }
    override func perform(action: Action) {
        super.perform(action: action)
        
        switch action {
        case .setCargo:
            hasCargo = true
        case .resetCargo:
            hasCargo = false
        default:
            break
            }
    }
}

let sportCar = SportCar(model: "TeslaS", hoursePower: 1000)
let trunkCar = TrunkCar(model: "TeslaSemi", hoursePower: 300)

sportCar.perform(action: .nitroOn)
sportCar.perform(action: .setCargo)

trunkCar.perform(action: .setCargo)
trunkCar.perform(action: .nitroOn)
