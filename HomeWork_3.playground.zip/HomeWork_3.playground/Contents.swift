import Foundation

//1. Описать несколько структур – любой легковой автомобиль SportCar и любой грузовик TrunkCar.
//2. Структуры должны содержать марку авто, год выпуска, объем багажника/кузова, запущен ли двигатель, открыты ли окна, заполненный объем багажника.
//3. Описать перечисление с возможными действиями с автомобилем: запустить/заглушить двигатель, открыть/закрыть окна, погрузить/выгрузить из кузова/багажника груз определенного объема.
//4. Добавить в структуры метод с одним аргументом типа перечисления, который будет менять свойства структуры в зависимости от действия.
//5. Инициализировать несколько экземпляров структур. Применить к ним различные действия.
//6. Вывести значения свойств экземпляров в консоль.

enum Action {
    case openDoor, closeDoor
    case openWindow, closeWindow
    case  turnOnEngine, turnOffEngine
    case setCargo(volume: Int)
}

struct SportCar {
    let model: String
    let year: Int
    var isWindowOpen: Bool
    var isDoorOpen: Bool
    var isEngineWork: Bool
    var currentVolume: Int //durating volume
    let maxVolime: Int //max

   mutating func performe(action: Action){
        switch action {
        case .closeDoor:
            isDoorOpen = false
        case .openDoor:
            isDoorOpen = true
        case .closeWindow:
            isWindowOpen = false
        case .openWindow:
            isWindowOpen = true
        case .turnOnEngine:
            isEngineWork = true
        case .turnOffEngine:
            isEngineWork = false
        case .setCargo (let volume):
            if currentVolume + volume <= maxVolime {
        currentVolume += volume
            } else {
                print ("Загрузка невозможна")
        }
    }
}
}

struct TrunkCar {
    let model: String
    let year: Int
    var isWindowOpen: Bool
    var isDoorOpen: Bool
    var isEngineWork: Bool
    var currentVolume: Int //durating volume
    let maxVolime: Int //max

   mutating func performe(action: Action){
        switch action {
        case .closeDoor:
            isDoorOpen = false
        case .openDoor:
            isDoorOpen = true
        case .closeWindow:
            isWindowOpen = false
        case .openWindow:
            isWindowOpen = true
        case .turnOnEngine:
            isEngineWork = true
        case .turnOffEngine:
            isEngineWork = false
        case .setCargo (let volume):
            if currentVolume + volume <= maxVolime {
        currentVolume += volume
            } else {
                print ("Загрузка невозможна")
        }
    }
}
}

var TeslaS = SportCar(model: "TeslaS",
                      year: 2022,
                      isWindowOpen: false,
                      isDoorOpen: false,
                      isEngineWork: false,
                      currentVolume: 0,
                      maxVolime: 55)

TeslaS.performe(action: .openDoor)

TeslaS.isDoorOpen

TeslaS.performe(action: .closeDoor)

TeslaS.isDoorOpen

TeslaS.performe(action: .turnOnEngine)

TeslaS.isEngineWork

TeslaS.performe(action: .setCargo(volume: 50))

TeslaS.currentVolume

TeslaS.performe(action: .setCargo(volume: 100))

TeslaS.currentVolume

var TeslaSemi = SportCar(model: "TeslaSemi",
                      year: 2022,
                      isWindowOpen: false,
                      isDoorOpen: false,
                      isEngineWork: false,
                      currentVolume: 0,
                      maxVolime: 55)

TeslaSemi.performe(action: .openDoor)

TeslaSemi.isDoorOpen

TeslaSemi.performe(action: .closeDoor)

TeslaSemi.isDoorOpen

TeslaSemi.performe(action: .turnOnEngine)

TeslaSemi.isEngineWork

TeslaSemi.performe(action: .setCargo(volume: 50))

TeslaSemi.currentVolume

TeslaSemi.performe(action: .setCargo(volume: 100))

TeslaSemi.currentVolume
